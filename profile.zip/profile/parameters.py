#The txt file containing parcel data
parcel_data = 'input/test.txt'

#Link in which the data is scraped
value_link = 'http://www.deltacomputersystems.com/MS/MS24DELTA/plinkquerym.html'
map_link =  'http://harrisonms.geopowered.com/propertysearch/'
spokeo_link = 'https://www.spokeo.com/login?url=%2F'

# File name in which the data is stored
value_file = 'data/value.csv'
link_file = 'data/link.csv'
spokeo_file = 'data/spokeo.csv'

#Spokeo credential for login in
spokeo_username = 'scottl@equitynv.com'
spokeo_password = 'Spokeo2019'
