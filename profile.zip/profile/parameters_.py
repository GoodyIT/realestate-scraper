spokeo_file = 'final.csv'
spokeo_link = 'https://www.spokeo.com/login'
spokeo_username = 'Scottl@equitynv.com'
spokeo_password = 'Spokeo2019'

parcel_data = 'parcel_data.txt'
link_file = 'link_file.csv'
map_link = 'https://maps.google.com/maps?layer=c&cbll=30.491946400421934,-89.33371365817366&cbp=12,0,,0,5&output=svembed&ll=30.491946400421934,-89.33371365817366'

value_file = 'value_file.csv'
value_link = ''

lien_file = 'lien_file.csv'
lien_link = ''
